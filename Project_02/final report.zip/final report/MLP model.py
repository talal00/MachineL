#!/usr/bin/env python
# coding: utf-8

# # Energy and market price forecasting using MLPR
# 

# # Import the libraries

# In[1]:


import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
get_ipython().run_line_magic('matplotlib', 'inline')


# # Loading and preparing the Data

# In[2]:


data=pd.read_csv("data.csv",parse_dates=[0])
df = data.set_index("Datetime") # set Datetime as an index
df=df.fillna(df.mean())
df.head()


# # Visulaising the data

# In[3]:


#Extracting some features from the data
final_df = (df.assign(year = df.index.year
                     ,month = df.index.month
                     ,day = df.index.day
                     ,day_of_year = df.index.dayofyear
                     ,week = df.index.week
                     ,week_day = df.index.weekday_name 
                     ,quarter = df.index.quarter
                     ,hour = df.index.hour)
           )

final_df.head()


# ## Visualizing Annual Energy Consumption

# In[28]:


# Visulaise the annual energy consumption
get_ipython().run_line_magic('matplotlib', 'inline')
from matplotlib import style
#Defining plotting style
style.use('ggplot')
fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(15,20))

#Plotting 2019,2020 energy consumption
axes[0].set_title('Consumption in 2019',color="red",size=(20))
axes[0].set_ylabel('Power(MW)',size=(15))
axes[0].set_xlabel('Datetime',size=(15))
final_df["2019"]["Actual_load"].plot(ax=axes[0],color="orange", linewidth=1)

axes[1].set_title('Consumption in 2020',color="red",size=(20))
axes[1].set_ylabel('Power(MW)',size=(15))
axes[1].set_xlabel('Datetime',size=(15))
final_df["2020"]["Actual_load"].plot(ax=axes[1],color="orange", linewidth=1)

plt.show()


# # Energy Distribution

# In[5]:


final_df["Actual_load"].plot.hist(figsize=(13, 7), bins=200, title='Distribution of Electricity Power Consumption')
plt.xlabel('Power (MWatt)')
plt.show()


# In[6]:


# Viulaise the consumption  with Respect to day time
get_ipython().run_line_magic('matplotlib', 'inline')
fig = plt.figure()
ax1= fig.add_subplot(111)

sns.lineplot(x=final_df["hour"],y=final_df["Actual_load"], data=df)
plt.title("Hourly Energy Consumption")
plt.xlabel("hour")
plt.grid(True, alpha=1)
plt.legend()
plt.show()


# ## Energy Forecasting using MLPR

# In[7]:


#Importing librarires
import pandas as pd
from sklearn.model_selection import train_test_split,cross_val_score
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


# In[8]:


#Actual load of year 2019
load19=final_df.loc[final_df['year'].isin([2019])].iloc[:,1]

#2019 year Features for training the model
features=pd.concat([final_df.iloc[:,0],final_df.iloc[:,2:]],axis=1)
features['week_day'] = features['week_day'].map({'Monday':1,'Tuesday': 2,'Wednesday':3,
                                             'Thursday':4,'Friday':5, 
                                             'Saturday': 6,'Sunday':7})
feature19=features.loc[features['year'].isin([2019])].fillna(features.mean())
feature19.head()


# In[9]:


#Removing less important features
cols = [1,4,5,7]
feature19=feature19.drop(feature19.columns[cols],axis=1)
feature19.head()


# In[10]:


#libraries for MLPR and accuracies check
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import accuracy_score, r2_score
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
#Splitting data into train and test set
X_train,X_test,y_train,y_test=train_test_split(feature19,load19,train_size=0.75,random_state=0)
#Defining mlpr model
mlp=Pipeline([('Scaling',StandardScaler()),
              ('MLPR',MLPRegressor(hidden_layer_sizes=(20,15,10,5),activation='relu',
                    solver='lbfgs',max_iter=1000,random_state=0))])

#Fitting features with target variable
mlp.fit(X=X_train, y=y_train)
#Predicting training set
yhat=mlp.predict(X_train)
#Checking accuracy of the model
RsquaredCV=cross_val_score(mlp, X_train, y_train, cv=5).mean()
RsquaredTR=mlp.score(X_train,y_train)
#Plotting model performance
sns.regplot(x=y_train,y=yhat, line_kws={"color": "red"},scatter_kws={"color": "green"})
plt.xlabel('True load')
plt.ylabel('Predicted load')
plt.title('Comparison of two-feature model, $R^2$=%3.2f' % RsquaredCV)
plt.show()
#Predicting test variable to check test accuracy
ypr_t=mlp.predict(X_test)
#Accuracy scores
print("CV score..........", RsquaredCV)
print("Training score....", RsquaredTR)
print("Test score........",r2_score(y_true=y_test,y_pred=ypr_t))


# In[11]:


from matplotlib.legend_handler import HandlerLine2D
from pandas.plotting import register_matplotlib_converters
#Forecasting 2019 energy consumption
y_pre=mlp.predict(feature19)
ytrue=load19
y_pre=pd.DataFrame(y_pre,columns=['Predicted Energy'])
y_pre.index=ytrue.index

#Plotting 2018 yearly consumption
plt.figure(figsize=(20,10))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'g',label='Predicted')
plt.xlabel('Date')
plt.ylabel('Energy MWh')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.show()


# In[12]:


#Actual load of year 2020 march and april
load20=final_df.loc[final_df['year'].isin([2020])]
load_march=load20.loc[load20['month'].isin([3])].iloc[:,1] #March 2020 actual load
load_april=load20.loc[load20['month'].isin([4])].iloc[:,1] #April 2020 actual load
load20=load20.iloc[:,1]
#2020 year features for predicting energy of year 2020
feature20=features.loc[features['year'].isin([2020])].fillna(features.mean())

#Extracting march features
feature_march=feature20.loc[feature20['month'].isin([3])]
#Extracting april features
feature_april=feature20.loc[feature20['month'].isin([4])]
feature_april

#Removing less important features
feature_march=feature_march.drop(feature_march.columns[cols],axis=1)
feature_april=feature_april.drop(feature_april.columns[cols],axis=1)
feature20=feature20.drop(feature20.columns[cols],axis=1)
feature20.head()


# In[13]:


#Forecasting 2020 march energy consumption
y_pre=mlp.predict(feature_march)
ytrue=load_march
y_pre=pd.DataFrame(y_pre,columns=['Predicted Energy'])
y_pre.index=ytrue.index

#Plotting predicted march energy 2020
plt.figure(figsize=(15,5))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'green',label='Predicted')
plt.xlabel('March')
plt.ylabel('Energy MWh')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.savefig("pic.jpg")
plt.show()


# In[14]:


#Forecasting 2020 april energy consumption
y_pre=mlp.predict(feature_april)
ytrue=load_april
y_pre=pd.DataFrame(y_pre,columns=['Predicted Energy'])
y_pre.index=ytrue.index

#Plotting predicted april energy 2020
plt.figure(figsize=(15,5))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'green',label='Predicted')
plt.xlabel('April')
plt.ylabel('Energy MWh')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.show()


# ## Visualizing Annual Market price

# In[15]:


# Visulaise the annual energy consumption
get_ipython().run_line_magic('matplotlib', 'inline')
fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(15,20))

axes[0].set_title('Market Price in 2019',color="red",size=(20))
axes[0].set_ylabel('Market Price(euro)',size=(15))
axes[0].set_xlabel('Datetime',size=(15))
final_df["2019"]["Market_price"].plot(ax=axes[0],color="orange", linewidth=1)

axes[1].set_title('Market Price in 2020',color="red",size=(20))
axes[1].set_ylabel('Market Price (euro)',size=(15))
axes[1].set_xlabel('Datetime',size=(15))
final_df["2020"]["Market_price"].plot(ax=axes[1],color="orange", linewidth=1)
#plt.tight_layout()
plt.show()


# ## Market Price Distribution

# In[16]:


final_df["Market_price"].plot.hist(figsize=(13, 7), bins=200, title='Distribution of Market price')
plt.xlabel('Market price (euro)')
plt.show()


# In[17]:


# Viulaise the consumption  with Respect to day time
get_ipython().run_line_magic('matplotlib', 'inline')
fig = plt.figure()
ax1= fig.add_subplot(111)

sns.lineplot(x=final_df["hour"],y=final_df["Market_price"], data=df)
plt.title("Hourly Market Price (euro)")
plt.xlabel("hour")
plt.grid(True, alpha=1)
plt.legend()
plt.show()


# ## Market price forecasting using MLPR

# In[18]:


#Actual market price of year 2019
mrk_prc19=final_df.loc[final_df['year'].isin([2019])].iloc[:,0].fillna(final_df.iloc[:,0].mean())

# 2019 year Features for training the model
features=final_df.iloc[:,1:]

#mapping weekday names against numbers
features['week_day'] = features['week_day'].map({'Monday':1,'Tuesday': 2,'Wednesday':3,
                                             'Thursday':4,'Friday':5, 
                                             'Saturday': 6,'Sunday':7})
feature19=features.loc[features['year'].isin([2019])]
feature19.head()


# In[19]:


#Removing less important features
cols = [1,4,5,7]
feature19=feature19.drop(feature19.columns[cols],axis=1)
feature19.head()


# In[32]:


from sklearn.neural_network import MLPRegressor
from sklearn import datasets
from sklearn.metrics import accuracy_score, r2_score
from sklearn.model_selection import cross_val_score

#Splitting data into train and test set
X_train,X_test,y_train,y_test=train_test_split(feature19,mrk_prc19,train_size=0.75,random_state=0)

#Defining mlpr model
mlp=Pipeline([('Scaling',StandardScaler()),
             ('MLPR',MLPRegressor(hidden_layer_sizes=(20,15,10,5),activation='relu',
                   solver='lbfgs',max_iter=5000,random_state=0))])

#Fitting features with target variable
mlp.fit(X=X_train, y=y_train)
#Predicting training set
yhat=mlp.predict(X_train)
#Checking accuracy of the model
RsquaredCV=cross_val_score(mlp, X_train, y_train, cv=5).mean()
RsquaredTR=mlp.score(X_train,y_train)

#Plotting model performance
sns.regplot(x=y_train,y=yhat, line_kws={"color": "red"},scatter_kws={"color": "green"})
plt.xlabel('True load')
plt.ylabel('Predicted load')
plt.title('Comparison of two-feature model, $R^2$=%3.2f' % RsquaredCV)

#Predicting test variable to check test accuracy
yhat=mlp.predict(X_test)

#Accuracy scores
print("CV score..........", RsquaredCV)
print("Training score....", RsquaredTR)
print("Test score........",r2_score(y_true=y_test,y_pred=yhat))


# In[33]:


#Forecasting market price of year 2019
y_pre=mlp.predict(feature19)
ytrue=mrk_prc19
y_pre=pd.DataFrame(y_pre,columns=['Predicted market price'])
y_pre.index=ytrue.index

#Plotting predicted marker price 2019
plt.figure(figsize=(20,10))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'g',label='Predicted')
plt.xlabel('Date')
plt.ylabel('Market price (euro)')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.show()


# In[37]:


#Actual marketprice of year 2020 march and april
mrk_prc20=final_df.loc[final_df['year'].isin([2020])].fillna(final_df.mean())
prc_march=mrk_prc20.loc[mrk_prc20['month'].isin([3])].iloc[:,0] #March 2020 actual market price
prc_april=mrk_prc20.loc[mrk_prc20['month'].isin([4])].iloc[:,0] #April 2020 actual market price
mrk_prc20=mrk_prc20.iloc[:,0]

#2020 year features for predicting energy of year 2020
feature20=features.loc[features['year'].isin([2020])].fillna(features.mean())

#Extracting march 2020 features
feature_march=feature20.loc[feature20['month'].isin([3])]
#Extracting april 2020 features
feature_april=feature20.loc[feature20['month'].isin([4])]

#Removing less important features
feature_march=feature_march.drop(feature_march.columns[cols],axis=1)
feature_april=feature_april.drop(feature_april.columns[cols],axis=1)
feature20=feature20.drop(feature20.columns[cols],axis=1)
feature20.head()


# In[35]:


#Forecasting market price of march 2020
y_pre=mlp.predict(feature_march)
ytrue=prc_march
y_pre=pd.DataFrame(y_pre,columns=['Predicted market price'])
y_pre.index=ytrue.index

#Plotting predicted march market price 2020
plt.figure(figsize=(20,5))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'green',label='Predicted')
plt.xlabel('March')
plt.ylabel('Market price (euro)')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.show()


# In[36]:


#Forecasting market price of april 2020
y_pre=mlp.predict(feature_april)
ytrue=prc_april
y_pre=pd.DataFrame(y_pre,columns=['Predicted market price'])
y_pre.index=ytrue.index

#Plotting predicted april market price 2020
plt.figure(figsize=(10,5))
line1,=plt.plot(ytrue,'r',label='Actual')
line2,=plt.plot(y_pre,'green',label='Predicted')
plt.xlabel('April')
plt.ylabel('Market price (euro)')
plt.title('MLP Regressor')
plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
plt.show()


# In[ ]:




